<template>
    <h3>Hello</h3>
</template>


<script>
export default {
    name: 'Inicio'
}

</script>