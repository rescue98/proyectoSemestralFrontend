<template>
    <form>
        <h3></h3>

        <div class="form-group">
            <label>Nombre</label>
            <input type="text" class="form-control" placeholder="Nombre" />
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="email" class="form-control" placeholder="Email" />
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" class="form-control" placeholder="Password" />
        </div>

        <div class="form-group">
            <label>Confirmar Password</label>
            <input type="password" class="form-control" placeholder="Confirmar Password" />
        </div>

        <button class="btn btn-primary btn-block">Registrar</button>
    </form>

</template>



<script>

export default {
    name: 'Registro'
}
</script>