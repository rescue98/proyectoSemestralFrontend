<template>
    <form>
        <h3></h3>

        <div class="form-group">
            <label>Nombre</label>
            <input type="nombre" class="form-control" placeholder="Nombre" />
        </div>

        <div class="form-group">
            <label>Clave</label>
            <input type="clave" class="form-control" placeholder="Clave" />
        </div>

        <button class="btn btn-primary btn-block">Login</button>
    </form>
</template>


<script>

export default {
    name: 'Login'
}
</script>