<template>
    <nav class="navbar navbar-expand navbar-light fixed-top">
        <div class="container">
            <a href="#" class="navbar-brand">Inicio</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a href="#" class="nav-link">Login</a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link">Registrar</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


</template>

<script>
export default {
    name: 'Nav'
}

</script>